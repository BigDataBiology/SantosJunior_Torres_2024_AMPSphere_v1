The file: 'truepep_gmgc_progenomes.m8.xz'
is available in the following address: ubuntu@aws.big-data-biology.org:/share/work/Celio/files_for_figures/databases_homology/
